def MultiplyTwoNumbers():
	a=10
	b=20
	res=a*b
	return str(res)